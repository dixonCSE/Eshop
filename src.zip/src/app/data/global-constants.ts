export class GlobalConstants {
    public static apiBaseURL: string = 'https://back.ecom.rcw100.net/ecom/api/';
    public static assetsBaseURL: string = 'https://back.ecom.rcw100.net/';
}
